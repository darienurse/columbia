Darien Nurse
Program 6

This program uses several data structure to complete a Traveling Salesperson Problem. When the program begins, a GUI will appear asking for a number. After entering a number, the user will press �Create Cities� to display N number of points on a canvas. �Draw Hull� will draw a convex hull around the points and �Insert Minimums� will find a tour around these points. 

There are no non-programming  problems with this file.

